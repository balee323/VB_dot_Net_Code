﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GameMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(GameMain))
        Me.A = New System.Windows.Forms.Label()
        Me.D = New System.Windows.Forms.Label()
        Me.C = New System.Windows.Forms.Label()
        Me.B = New System.Windows.Forms.Label()
        Me.F = New System.Windows.Forms.Label()
        Me.G = New System.Windows.Forms.Label()
        Me.H = New System.Windows.Forms.Label()
        Me.EE = New System.Windows.Forms.Label()
        Me.J = New System.Windows.Forms.Label()
        Me.K = New System.Windows.Forms.Label()
        Me.L = New System.Windows.Forms.Label()
        Me.I = New System.Windows.Forms.Label()
        Me.N = New System.Windows.Forms.Label()
        Me.O = New System.Windows.Forms.Label()
        Me.P = New System.Windows.Forms.Label()
        Me.Z = New System.Windows.Forms.Label()
        Me.R = New System.Windows.Forms.Label()
        Me.S = New System.Windows.Forms.Label()
        Me.T = New System.Windows.Forms.Label()
        Me.Q = New System.Windows.Forms.Label()
        Me.V = New System.Windows.Forms.Label()
        Me.W = New System.Windows.Forms.Label()
        Me.X = New System.Windows.Forms.Label()
        Me.U = New System.Windows.Forms.Label()
        Me.M = New System.Windows.Forms.Label()
        Me.Y = New System.Windows.Forms.Label()
        Me.TxtWordBox = New System.Windows.Forms.TextBox()
        Me.PIC6 = New System.Windows.Forms.PictureBox()
        Me.PIC5 = New System.Windows.Forms.PictureBox()
        Me.PIC4 = New System.Windows.Forms.PictureBox()
        Me.PIC3 = New System.Windows.Forms.PictureBox()
        Me.PIC2 = New System.Windows.Forms.PictureBox()
        Me.PIC1 = New System.Windows.Forms.PictureBox()
        Me.BtnStart = New System.Windows.Forms.Button()
        Me.BtnQuit = New System.Windows.Forms.Button()
        Me.TxtScore = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BtnLoadFile = New System.Windows.Forms.Button()
        CType(Me.PIC6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PIC5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PIC4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PIC3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PIC2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PIC1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'A
        '
        Me.A.AutoSize = True
        Me.A.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.A.Location = New System.Drawing.Point(76, 11)
        Me.A.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.A.Name = "A"
        Me.A.Size = New System.Drawing.Size(41, 39)
        Me.A.TabIndex = 0
        Me.A.Text = "A"
        Me.A.Visible = False
        '
        'D
        '
        Me.D.AutoSize = True
        Me.D.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.D.Location = New System.Drawing.Point(201, 11)
        Me.D.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.D.Name = "D"
        Me.D.Size = New System.Drawing.Size(43, 39)
        Me.D.TabIndex = 9
        Me.D.Text = "D"
        Me.D.Visible = False
        '
        'C
        '
        Me.C.AutoSize = True
        Me.C.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C.Location = New System.Drawing.Point(160, 11)
        Me.C.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.C.Name = "C"
        Me.C.Size = New System.Drawing.Size(43, 39)
        Me.C.TabIndex = 10
        Me.C.Text = "C"
        Me.C.Visible = False
        '
        'B
        '
        Me.B.AutoSize = True
        Me.B.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.B.Location = New System.Drawing.Point(118, 11)
        Me.B.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.B.Name = "B"
        Me.B.Size = New System.Drawing.Size(41, 39)
        Me.B.TabIndex = 11
        Me.B.Text = "B"
        Me.B.Visible = False
        '
        'F
        '
        Me.F.AutoSize = True
        Me.F.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.F.Location = New System.Drawing.Point(283, 11)
        Me.F.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.F.Name = "F"
        Me.F.Size = New System.Drawing.Size(39, 39)
        Me.F.TabIndex = 15
        Me.F.Text = "F"
        Me.F.Visible = False
        '
        'G
        '
        Me.G.AutoSize = True
        Me.G.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.G.Location = New System.Drawing.Point(315, 11)
        Me.G.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.G.Name = "G"
        Me.G.Size = New System.Drawing.Size(44, 39)
        Me.G.TabIndex = 14
        Me.G.Text = "G"
        Me.G.Visible = False
        '
        'H
        '
        Me.H.AutoSize = True
        Me.H.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.H.Location = New System.Drawing.Point(358, 11)
        Me.H.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.H.Name = "H"
        Me.H.Size = New System.Drawing.Size(43, 39)
        Me.H.TabIndex = 13
        Me.H.Text = "H"
        Me.H.Visible = False
        '
        'EE
        '
        Me.EE.AutoSize = True
        Me.EE.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EE.Location = New System.Drawing.Point(244, 11)
        Me.EE.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.EE.Name = "EE"
        Me.EE.Size = New System.Drawing.Size(41, 39)
        Me.EE.TabIndex = 12
        Me.EE.Text = "E"
        Me.EE.Visible = False
        '
        'J
        '
        Me.J.AutoSize = True
        Me.J.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.J.Location = New System.Drawing.Point(437, 11)
        Me.J.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.J.Name = "J"
        Me.J.Size = New System.Drawing.Size(35, 39)
        Me.J.TabIndex = 19
        Me.J.Text = "J"
        Me.J.Visible = False
        '
        'K
        '
        Me.K.AutoSize = True
        Me.K.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.K.Location = New System.Drawing.Point(487, 11)
        Me.K.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.K.Name = "K"
        Me.K.Size = New System.Drawing.Size(41, 39)
        Me.K.TabIndex = 18
        Me.K.Text = "K"
        Me.K.Visible = False
        '
        'L
        '
        Me.L.AutoSize = True
        Me.L.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L.Location = New System.Drawing.Point(526, 11)
        Me.L.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.L.Name = "L"
        Me.L.Size = New System.Drawing.Size(37, 39)
        Me.L.TabIndex = 17
        Me.L.Text = "L"
        Me.L.Visible = False
        '
        'I
        '
        Me.I.AutoSize = True
        Me.I.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.I.Location = New System.Drawing.Point(402, 11)
        Me.I.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.I.Name = "I"
        Me.I.Size = New System.Drawing.Size(28, 39)
        Me.I.TabIndex = 16
        Me.I.Text = "I"
        Me.I.Visible = False
        '
        'N
        '
        Me.N.AutoSize = True
        Me.N.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.N.Location = New System.Drawing.Point(76, 57)
        Me.N.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.N.Name = "N"
        Me.N.Size = New System.Drawing.Size(43, 39)
        Me.N.TabIndex = 23
        Me.N.Text = "N"
        Me.N.Visible = False
        '
        'O
        '
        Me.O.AutoSize = True
        Me.O.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.O.Location = New System.Drawing.Point(116, 57)
        Me.O.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.O.Name = "O"
        Me.O.Size = New System.Drawing.Size(44, 39)
        Me.O.TabIndex = 22
        Me.O.Text = "O"
        Me.O.Visible = False
        '
        'P
        '
        Me.P.AutoSize = True
        Me.P.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.P.Location = New System.Drawing.Point(159, 57)
        Me.P.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.P.Name = "P"
        Me.P.Size = New System.Drawing.Size(41, 39)
        Me.P.TabIndex = 21
        Me.P.Text = "P"
        Me.P.Visible = False
        '
        'Z
        '
        Me.Z.AutoSize = True
        Me.Z.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Z.Location = New System.Drawing.Point(567, 57)
        Me.Z.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Z.Name = "Z"
        Me.Z.Size = New System.Drawing.Size(39, 39)
        Me.Z.TabIndex = 20
        Me.Z.Text = "Z"
        Me.Z.Visible = False
        '
        'R
        '
        Me.R.AutoSize = True
        Me.R.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.R.Location = New System.Drawing.Point(241, 57)
        Me.R.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.R.Name = "R"
        Me.R.Size = New System.Drawing.Size(43, 39)
        Me.R.TabIndex = 27
        Me.R.Text = "R"
        Me.R.Visible = False
        '
        'S
        '
        Me.S.AutoSize = True
        Me.S.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.S.Location = New System.Drawing.Point(281, 57)
        Me.S.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.S.Name = "S"
        Me.S.Size = New System.Drawing.Size(41, 39)
        Me.S.TabIndex = 26
        Me.S.Text = "S"
        Me.S.Visible = False
        '
        'T
        '
        Me.T.AutoSize = True
        Me.T.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.T.Location = New System.Drawing.Point(320, 57)
        Me.T.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.T.Name = "T"
        Me.T.Size = New System.Drawing.Size(39, 39)
        Me.T.TabIndex = 25
        Me.T.Text = "T"
        Me.T.Visible = False
        '
        'Q
        '
        Me.Q.AutoSize = True
        Me.Q.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Q.Location = New System.Drawing.Point(198, 57)
        Me.Q.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Q.Name = "Q"
        Me.Q.Size = New System.Drawing.Size(44, 39)
        Me.Q.TabIndex = 24
        Me.Q.Text = "Q"
        Me.Q.Visible = False
        '
        'V
        '
        Me.V.AutoSize = True
        Me.V.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.V.Location = New System.Drawing.Point(398, 57)
        Me.V.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.V.Name = "V"
        Me.V.Size = New System.Drawing.Size(41, 39)
        Me.V.TabIndex = 31
        Me.V.Text = "V"
        Me.V.Visible = False
        '
        'W
        '
        Me.W.AutoSize = True
        Me.W.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.W.Location = New System.Drawing.Point(437, 57)
        Me.W.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.W.Name = "W"
        Me.W.Size = New System.Drawing.Size(50, 39)
        Me.W.TabIndex = 30
        Me.W.Text = "W"
        Me.W.Visible = False
        '
        'X
        '
        Me.X.AutoSize = True
        Me.X.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.X.Location = New System.Drawing.Point(484, 57)
        Me.X.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.X.Name = "X"
        Me.X.Size = New System.Drawing.Size(41, 39)
        Me.X.TabIndex = 29
        Me.X.Text = "X"
        Me.X.Visible = False
        '
        'U
        '
        Me.U.AutoSize = True
        Me.U.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.U.Location = New System.Drawing.Point(358, 57)
        Me.U.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.U.Name = "U"
        Me.U.Size = New System.Drawing.Size(43, 39)
        Me.U.TabIndex = 28
        Me.U.Text = "U"
        Me.U.Visible = False
        '
        'M
        '
        Me.M.AutoSize = True
        Me.M.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.M.Location = New System.Drawing.Point(562, 11)
        Me.M.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.M.Name = "M"
        Me.M.Size = New System.Drawing.Size(46, 39)
        Me.M.TabIndex = 35
        Me.M.Text = "M"
        Me.M.Visible = False
        '
        'Y
        '
        Me.Y.AutoSize = True
        Me.Y.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Y.Location = New System.Drawing.Point(524, 57)
        Me.Y.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Y.Name = "Y"
        Me.Y.Size = New System.Drawing.Size(40, 39)
        Me.Y.TabIndex = 32
        Me.Y.Text = "Y"
        Me.Y.Visible = False
        '
        'TxtWordBox
        '
        Me.TxtWordBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.21818!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtWordBox.Location = New System.Drawing.Point(40, 134)
        Me.TxtWordBox.Margin = New System.Windows.Forms.Padding(2)
        Me.TxtWordBox.Multiline = True
        Me.TxtWordBox.Name = "TxtWordBox"
        Me.TxtWordBox.Size = New System.Drawing.Size(597, 54)
        Me.TxtWordBox.TabIndex = 36
        Me.TxtWordBox.TabStop = False
        Me.TxtWordBox.Text = "HANGMAN!"
        Me.TxtWordBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'PIC6
        '
        Me.PIC6.Image = CType(resources.GetObject("PIC6.Image"), System.Drawing.Image)
        Me.PIC6.Location = New System.Drawing.Point(40, 239)
        Me.PIC6.Margin = New System.Windows.Forms.Padding(2)
        Me.PIC6.Name = "PIC6"
        Me.PIC6.Size = New System.Drawing.Size(597, 349)
        Me.PIC6.TabIndex = 37
        Me.PIC6.TabStop = False
        '
        'PIC5
        '
        Me.PIC5.Image = CType(resources.GetObject("PIC5.Image"), System.Drawing.Image)
        Me.PIC5.Location = New System.Drawing.Point(40, 239)
        Me.PIC5.Margin = New System.Windows.Forms.Padding(2)
        Me.PIC5.Name = "PIC5"
        Me.PIC5.Size = New System.Drawing.Size(597, 349)
        Me.PIC5.TabIndex = 38
        Me.PIC5.TabStop = False
        '
        'PIC4
        '
        Me.PIC4.Image = CType(resources.GetObject("PIC4.Image"), System.Drawing.Image)
        Me.PIC4.Location = New System.Drawing.Point(40, 239)
        Me.PIC4.Margin = New System.Windows.Forms.Padding(2)
        Me.PIC4.Name = "PIC4"
        Me.PIC4.Size = New System.Drawing.Size(597, 349)
        Me.PIC4.TabIndex = 39
        Me.PIC4.TabStop = False
        '
        'PIC3
        '
        Me.PIC3.Image = CType(resources.GetObject("PIC3.Image"), System.Drawing.Image)
        Me.PIC3.Location = New System.Drawing.Point(40, 239)
        Me.PIC3.Margin = New System.Windows.Forms.Padding(2)
        Me.PIC3.Name = "PIC3"
        Me.PIC3.Size = New System.Drawing.Size(597, 349)
        Me.PIC3.TabIndex = 40
        Me.PIC3.TabStop = False
        '
        'PIC2
        '
        Me.PIC2.Image = CType(resources.GetObject("PIC2.Image"), System.Drawing.Image)
        Me.PIC2.InitialImage = CType(resources.GetObject("PIC2.InitialImage"), System.Drawing.Image)
        Me.PIC2.Location = New System.Drawing.Point(40, 239)
        Me.PIC2.Margin = New System.Windows.Forms.Padding(2)
        Me.PIC2.Name = "PIC2"
        Me.PIC2.Size = New System.Drawing.Size(597, 349)
        Me.PIC2.TabIndex = 41
        Me.PIC2.TabStop = False
        '
        'PIC1
        '
        Me.PIC1.Image = CType(resources.GetObject("PIC1.Image"), System.Drawing.Image)
        Me.PIC1.Location = New System.Drawing.Point(40, 239)
        Me.PIC1.Margin = New System.Windows.Forms.Padding(2)
        Me.PIC1.Name = "PIC1"
        Me.PIC1.Size = New System.Drawing.Size(597, 349)
        Me.PIC1.TabIndex = 42
        Me.PIC1.TabStop = False
        '
        'BtnStart
        '
        Me.BtnStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.818182!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnStart.Location = New System.Drawing.Point(653, 382)
        Me.BtnStart.Margin = New System.Windows.Forms.Padding(2)
        Me.BtnStart.Name = "BtnStart"
        Me.BtnStart.Size = New System.Drawing.Size(124, 72)
        Me.BtnStart.TabIndex = 43
        Me.BtnStart.TabStop = False
        Me.BtnStart.Text = "Start / Next"
        Me.BtnStart.UseVisualStyleBackColor = True
        '
        'BtnQuit
        '
        Me.BtnQuit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.818182!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnQuit.Location = New System.Drawing.Point(669, 522)
        Me.BtnQuit.Margin = New System.Windows.Forms.Padding(2)
        Me.BtnQuit.Name = "BtnQuit"
        Me.BtnQuit.Size = New System.Drawing.Size(94, 54)
        Me.BtnQuit.TabIndex = 44
        Me.BtnQuit.TabStop = False
        Me.BtnQuit.Text = "Quit"
        Me.BtnQuit.UseVisualStyleBackColor = True
        '
        'TxtScore
        '
        Me.TxtScore.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.818182!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtScore.Location = New System.Drawing.Point(668, 57)
        Me.TxtScore.Margin = New System.Windows.Forms.Padding(2)
        Me.TxtScore.Multiline = True
        Me.TxtScore.Name = "TxtScore"
        Me.TxtScore.ReadOnly = True
        Me.TxtScore.Size = New System.Drawing.Size(96, 30)
        Me.TxtScore.TabIndex = 45
        Me.TxtScore.TabStop = False
        Me.TxtScore.Text = "0"
        Me.TxtScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.818182!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(666, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(98, 20)
        Me.Label1.TabIndex = 46
        Me.Label1.Text = "High Score"
        '
        'BtnLoadFile
        '
        Me.BtnLoadFile.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.818182!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLoadFile.Location = New System.Drawing.Point(670, 239)
        Me.BtnLoadFile.Margin = New System.Windows.Forms.Padding(2)
        Me.BtnLoadFile.Name = "BtnLoadFile"
        Me.BtnLoadFile.Size = New System.Drawing.Size(94, 54)
        Me.BtnLoadFile.TabIndex = 47
        Me.BtnLoadFile.TabStop = False
        Me.BtnLoadFile.Text = "Load File"
        Me.BtnLoadFile.UseVisualStyleBackColor = True
        '
        'GameMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(788, 587)
        Me.Controls.Add(Me.BtnLoadFile)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TxtScore)
        Me.Controls.Add(Me.BtnQuit)
        Me.Controls.Add(Me.BtnStart)
        Me.Controls.Add(Me.PIC1)
        Me.Controls.Add(Me.PIC2)
        Me.Controls.Add(Me.PIC3)
        Me.Controls.Add(Me.PIC4)
        Me.Controls.Add(Me.PIC5)
        Me.Controls.Add(Me.PIC6)
        Me.Controls.Add(Me.TxtWordBox)
        Me.Controls.Add(Me.M)
        Me.Controls.Add(Me.Y)
        Me.Controls.Add(Me.V)
        Me.Controls.Add(Me.W)
        Me.Controls.Add(Me.X)
        Me.Controls.Add(Me.U)
        Me.Controls.Add(Me.R)
        Me.Controls.Add(Me.S)
        Me.Controls.Add(Me.T)
        Me.Controls.Add(Me.Q)
        Me.Controls.Add(Me.N)
        Me.Controls.Add(Me.O)
        Me.Controls.Add(Me.P)
        Me.Controls.Add(Me.Z)
        Me.Controls.Add(Me.J)
        Me.Controls.Add(Me.K)
        Me.Controls.Add(Me.L)
        Me.Controls.Add(Me.I)
        Me.Controls.Add(Me.F)
        Me.Controls.Add(Me.G)
        Me.Controls.Add(Me.H)
        Me.Controls.Add(Me.EE)
        Me.Controls.Add(Me.B)
        Me.Controls.Add(Me.C)
        Me.Controls.Add(Me.D)
        Me.Controls.Add(Me.A)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "GameMain"
        Me.Text = "HANGMAN GAME"
        CType(Me.PIC6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PIC5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PIC4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PIC3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PIC2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PIC1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents A As System.Windows.Forms.Label
    Friend WithEvents D As System.Windows.Forms.Label
    Friend WithEvents C As System.Windows.Forms.Label
    Friend WithEvents B As System.Windows.Forms.Label
    Friend WithEvents F As System.Windows.Forms.Label
    Friend WithEvents G As System.Windows.Forms.Label
    Friend WithEvents H As System.Windows.Forms.Label
    Friend WithEvents EE As System.Windows.Forms.Label
    Friend WithEvents J As System.Windows.Forms.Label
    Friend WithEvents K As System.Windows.Forms.Label
    Friend WithEvents L As System.Windows.Forms.Label
    Friend WithEvents I As System.Windows.Forms.Label
    Friend WithEvents N As System.Windows.Forms.Label
    Friend WithEvents O As System.Windows.Forms.Label
    Friend WithEvents P As System.Windows.Forms.Label
    Friend WithEvents Z As System.Windows.Forms.Label
    Friend WithEvents R As System.Windows.Forms.Label
    Friend WithEvents S As System.Windows.Forms.Label
    Friend WithEvents T As System.Windows.Forms.Label
    Friend WithEvents Q As System.Windows.Forms.Label
    Friend WithEvents V As System.Windows.Forms.Label
    Friend WithEvents W As System.Windows.Forms.Label
    Friend WithEvents X As System.Windows.Forms.Label
    Friend WithEvents U As System.Windows.Forms.Label
    Friend WithEvents M As System.Windows.Forms.Label
    Friend WithEvents Y As System.Windows.Forms.Label
    Friend WithEvents TxtWordBox As System.Windows.Forms.TextBox
    Friend WithEvents PIC6 As System.Windows.Forms.PictureBox
    Friend WithEvents PIC5 As System.Windows.Forms.PictureBox
    Friend WithEvents PIC4 As System.Windows.Forms.PictureBox
    Friend WithEvents PIC3 As System.Windows.Forms.PictureBox
    Friend WithEvents PIC2 As System.Windows.Forms.PictureBox
    Friend WithEvents PIC1 As System.Windows.Forms.PictureBox
    Friend WithEvents BtnStart As System.Windows.Forms.Button
    Friend WithEvents BtnQuit As System.Windows.Forms.Button
    Friend WithEvents TxtScore As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents BtnLoadFile As System.Windows.Forms.Button

End Class
