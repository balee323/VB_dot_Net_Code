﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmWhoMillionare
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmWhoMillionare))
        Me.lbl100 = New System.Windows.Forms.Label()
        Me.Lbl200 = New System.Windows.Forms.Label()
        Me.Lbl300 = New System.Windows.Forms.Label()
        Me.Lbl500 = New System.Windows.Forms.Label()
        Me.Lbl1k = New System.Windows.Forms.Label()
        Me.Lbl2k = New System.Windows.Forms.Label()
        Me.Lbl4k = New System.Windows.Forms.Label()
        Me.Lbl8k = New System.Windows.Forms.Label()
        Me.Lbl16k = New System.Windows.Forms.Label()
        Me.Lbl32k = New System.Windows.Forms.Label()
        Me.Lbl64k = New System.Windows.Forms.Label()
        Me.Lbl125k = New System.Windows.Forms.Label()
        Me.Lbl250k = New System.Windows.Forms.Label()
        Me.Lbl500k = New System.Windows.Forms.Label()
        Me.lblMillion = New System.Windows.Forms.Label()
        Me.BtnPlay = New System.Windows.Forms.Button()
        Me.RadA = New System.Windows.Forms.RadioButton()
        Me.LblA = New System.Windows.Forms.Panel()
        Me.LblD = New System.Windows.Forms.Label()
        Me.LblC = New System.Windows.Forms.Label()
        Me.LblB = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.BtnNext = New System.Windows.Forms.Button()
        Me.TxtQuestion = New System.Windows.Forms.TextBox()
        Me.BtnFinal = New System.Windows.Forms.Button()
        Me.RadD = New System.Windows.Forms.RadioButton()
        Me.RadB = New System.Windows.Forms.RadioButton()
        Me.RadC = New System.Windows.Forms.RadioButton()
        Me.BtnPhone = New System.Windows.Forms.Button()
        Me.Btn50_50 = New System.Windows.Forms.Button()
        Me.BtnAudience = New System.Windows.Forms.Button()
        Me.GrpHelpers = New System.Windows.Forms.GroupBox()
        Me.TxtCash = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BtnExit = New System.Windows.Forms.Button()
        Me.BtnRules = New System.Windows.Forms.Button()
        Me.BtnCreate = New System.Windows.Forms.Button()
        Me.BtnLoad = New System.Windows.Forms.Button()
        Me.BtnNew = New System.Windows.Forms.Button()
        Me.LblA.SuspendLayout()
        Me.GrpHelpers.SuspendLayout()
        Me.SuspendLayout()
        '
        'lbl100
        '
        Me.lbl100.AutoSize = True
        Me.lbl100.BackColor = System.Drawing.Color.Black
        Me.lbl100.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl100.ForeColor = System.Drawing.Color.Gold
        Me.lbl100.Location = New System.Drawing.Point(291, 595)
        Me.lbl100.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl100.Name = "lbl100"
        Me.lbl100.Size = New System.Drawing.Size(66, 25)
        Me.lbl100.TabIndex = 0
        Me.lbl100.Text = "$ 100"
        Me.lbl100.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl200
        '
        Me.Lbl200.AutoSize = True
        Me.Lbl200.BackColor = System.Drawing.Color.Black
        Me.Lbl200.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl200.ForeColor = System.Drawing.Color.Gold
        Me.Lbl200.Location = New System.Drawing.Point(291, 548)
        Me.Lbl200.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl200.Name = "Lbl200"
        Me.Lbl200.Size = New System.Drawing.Size(66, 25)
        Me.Lbl200.TabIndex = 1
        Me.Lbl200.Text = "$ 200"
        Me.Lbl200.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl300
        '
        Me.Lbl300.AutoSize = True
        Me.Lbl300.BackColor = System.Drawing.Color.Black
        Me.Lbl300.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl300.ForeColor = System.Drawing.Color.Gold
        Me.Lbl300.Location = New System.Drawing.Point(291, 504)
        Me.Lbl300.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl300.Name = "Lbl300"
        Me.Lbl300.Size = New System.Drawing.Size(66, 25)
        Me.Lbl300.TabIndex = 2
        Me.Lbl300.Text = "$ 300"
        Me.Lbl300.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl500
        '
        Me.Lbl500.AutoSize = True
        Me.Lbl500.BackColor = System.Drawing.Color.Black
        Me.Lbl500.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl500.ForeColor = System.Drawing.Color.Gold
        Me.Lbl500.Location = New System.Drawing.Point(291, 453)
        Me.Lbl500.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl500.Name = "Lbl500"
        Me.Lbl500.Size = New System.Drawing.Size(66, 25)
        Me.Lbl500.TabIndex = 3
        Me.Lbl500.Text = "$ 500"
        Me.Lbl500.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl1k
        '
        Me.Lbl1k.AutoSize = True
        Me.Lbl1k.BackColor = System.Drawing.Color.Black
        Me.Lbl1k.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl1k.ForeColor = System.Drawing.Color.Gold
        Me.Lbl1k.Location = New System.Drawing.Point(273, 410)
        Me.Lbl1k.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl1k.Name = "Lbl1k"
        Me.Lbl1k.Size = New System.Drawing.Size(84, 25)
        Me.Lbl1k.TabIndex = 4
        Me.Lbl1k.Text = "$ 1,000"
        Me.Lbl1k.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl2k
        '
        Me.Lbl2k.AutoSize = True
        Me.Lbl2k.BackColor = System.Drawing.Color.Black
        Me.Lbl2k.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl2k.ForeColor = System.Drawing.Color.Gold
        Me.Lbl2k.Location = New System.Drawing.Point(273, 371)
        Me.Lbl2k.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl2k.Name = "Lbl2k"
        Me.Lbl2k.Size = New System.Drawing.Size(84, 25)
        Me.Lbl2k.TabIndex = 5
        Me.Lbl2k.Text = "$ 2,000"
        Me.Lbl2k.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl4k
        '
        Me.Lbl4k.AutoSize = True
        Me.Lbl4k.BackColor = System.Drawing.Color.Black
        Me.Lbl4k.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl4k.ForeColor = System.Drawing.Color.Gold
        Me.Lbl4k.Location = New System.Drawing.Point(273, 327)
        Me.Lbl4k.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl4k.Name = "Lbl4k"
        Me.Lbl4k.Size = New System.Drawing.Size(84, 25)
        Me.Lbl4k.TabIndex = 6
        Me.Lbl4k.Text = "$ 4,000"
        Me.Lbl4k.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl8k
        '
        Me.Lbl8k.AutoSize = True
        Me.Lbl8k.BackColor = System.Drawing.Color.Black
        Me.Lbl8k.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl8k.ForeColor = System.Drawing.Color.Gold
        Me.Lbl8k.Location = New System.Drawing.Point(273, 288)
        Me.Lbl8k.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl8k.Name = "Lbl8k"
        Me.Lbl8k.Size = New System.Drawing.Size(84, 25)
        Me.Lbl8k.TabIndex = 7
        Me.Lbl8k.Text = "$ 8,000"
        Me.Lbl8k.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl16k
        '
        Me.Lbl16k.AutoSize = True
        Me.Lbl16k.BackColor = System.Drawing.Color.Black
        Me.Lbl16k.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl16k.ForeColor = System.Drawing.Color.Gold
        Me.Lbl16k.Location = New System.Drawing.Point(261, 250)
        Me.Lbl16k.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl16k.Name = "Lbl16k"
        Me.Lbl16k.Size = New System.Drawing.Size(96, 25)
        Me.Lbl16k.TabIndex = 8
        Me.Lbl16k.Text = "$ 16,000"
        Me.Lbl16k.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl32k
        '
        Me.Lbl32k.AutoSize = True
        Me.Lbl32k.BackColor = System.Drawing.Color.Black
        Me.Lbl32k.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl32k.ForeColor = System.Drawing.Color.Gold
        Me.Lbl32k.Location = New System.Drawing.Point(261, 212)
        Me.Lbl32k.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl32k.Name = "Lbl32k"
        Me.Lbl32k.Size = New System.Drawing.Size(96, 25)
        Me.Lbl32k.TabIndex = 9
        Me.Lbl32k.Text = "$ 32,000"
        Me.Lbl32k.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl64k
        '
        Me.Lbl64k.AutoSize = True
        Me.Lbl64k.BackColor = System.Drawing.Color.Black
        Me.Lbl64k.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl64k.ForeColor = System.Drawing.Color.Gold
        Me.Lbl64k.Location = New System.Drawing.Point(261, 176)
        Me.Lbl64k.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl64k.Name = "Lbl64k"
        Me.Lbl64k.Size = New System.Drawing.Size(96, 25)
        Me.Lbl64k.TabIndex = 10
        Me.Lbl64k.Text = "$ 64,000"
        Me.Lbl64k.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl125k
        '
        Me.Lbl125k.AutoSize = True
        Me.Lbl125k.BackColor = System.Drawing.Color.Black
        Me.Lbl125k.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl125k.ForeColor = System.Drawing.Color.Gold
        Me.Lbl125k.Location = New System.Drawing.Point(249, 134)
        Me.Lbl125k.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl125k.Name = "Lbl125k"
        Me.Lbl125k.Size = New System.Drawing.Size(108, 25)
        Me.Lbl125k.TabIndex = 11
        Me.Lbl125k.Text = "$ 125,000"
        Me.Lbl125k.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl250k
        '
        Me.Lbl250k.AutoSize = True
        Me.Lbl250k.BackColor = System.Drawing.Color.Black
        Me.Lbl250k.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl250k.ForeColor = System.Drawing.Color.Gold
        Me.Lbl250k.Location = New System.Drawing.Point(249, 96)
        Me.Lbl250k.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl250k.Name = "Lbl250k"
        Me.Lbl250k.Size = New System.Drawing.Size(108, 25)
        Me.Lbl250k.TabIndex = 12
        Me.Lbl250k.Text = "$ 250,000"
        Me.Lbl250k.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl500k
        '
        Me.Lbl500k.AutoSize = True
        Me.Lbl500k.BackColor = System.Drawing.Color.Black
        Me.Lbl500k.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl500k.ForeColor = System.Drawing.Color.Gold
        Me.Lbl500k.Location = New System.Drawing.Point(249, 60)
        Me.Lbl500k.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl500k.Name = "Lbl500k"
        Me.Lbl500k.Size = New System.Drawing.Size(108, 25)
        Me.Lbl500k.TabIndex = 13
        Me.Lbl500k.Text = "$ 500,000"
        Me.Lbl500k.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblMillion
        '
        Me.lblMillion.AutoSize = True
        Me.lblMillion.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblMillion.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMillion.ForeColor = System.Drawing.Color.Gold
        Me.lblMillion.Location = New System.Drawing.Point(237, 21)
        Me.lblMillion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblMillion.Name = "lblMillion"
        Me.lblMillion.Size = New System.Drawing.Size(120, 25)
        Me.lblMillion.TabIndex = 14
        Me.lblMillion.Text = "$1,000,000"
        Me.lblMillion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'BtnPlay
        '
        Me.BtnPlay.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.BtnPlay.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnPlay.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPlay.ForeColor = System.Drawing.Color.Gold
        Me.BtnPlay.Location = New System.Drawing.Point(12, 183)
        Me.BtnPlay.Margin = New System.Windows.Forms.Padding(4)
        Me.BtnPlay.Name = "BtnPlay"
        Me.BtnPlay.Size = New System.Drawing.Size(139, 78)
        Me.BtnPlay.TabIndex = 15
        Me.BtnPlay.TabStop = False
        Me.BtnPlay.Text = "Start Game"
        Me.BtnPlay.UseVisualStyleBackColor = False
        '
        'RadA
        '
        Me.RadA.AutoSize = True
        Me.RadA.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadA.Location = New System.Drawing.Point(33, 179)
        Me.RadA.Margin = New System.Windows.Forms.Padding(4)
        Me.RadA.Name = "RadA"
        Me.RadA.Size = New System.Drawing.Size(17, 16)
        Me.RadA.TabIndex = 17
        Me.RadA.UseVisualStyleBackColor = True
        '
        'LblA
        '
        Me.LblA.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.LblA.BackColor = System.Drawing.Color.Olive
        Me.LblA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblA.Controls.Add(Me.LblD)
        Me.LblA.Controls.Add(Me.LblC)
        Me.LblA.Controls.Add(Me.LblB)
        Me.LblA.Controls.Add(Me.Label2)
        Me.LblA.Controls.Add(Me.BtnNext)
        Me.LblA.Controls.Add(Me.TxtQuestion)
        Me.LblA.Controls.Add(Me.BtnFinal)
        Me.LblA.Controls.Add(Me.RadD)
        Me.LblA.Controls.Add(Me.RadB)
        Me.LblA.Controls.Add(Me.RadC)
        Me.LblA.Controls.Add(Me.RadA)
        Me.LblA.Location = New System.Drawing.Point(391, 176)
        Me.LblA.Margin = New System.Windows.Forms.Padding(4)
        Me.LblA.Name = "LblA"
        Me.LblA.Size = New System.Drawing.Size(533, 450)
        Me.LblA.TabIndex = 18
        '
        'LblD
        '
        Me.LblD.AutoSize = True
        Me.LblD.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblD.Location = New System.Drawing.Point(5, 359)
        Me.LblD.Name = "LblD"
        Me.LblD.Size = New System.Drawing.Size(23, 20)
        Me.LblD.TabIndex = 27
        Me.LblD.Text = "D"
        '
        'LblC
        '
        Me.LblC.AutoSize = True
        Me.LblC.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblC.Location = New System.Drawing.Point(5, 300)
        Me.LblC.Name = "LblC"
        Me.LblC.Size = New System.Drawing.Size(22, 20)
        Me.LblC.TabIndex = 26
        Me.LblC.Text = "C"
        '
        'LblB
        '
        Me.LblB.AutoSize = True
        Me.LblB.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblB.Location = New System.Drawing.Point(5, 237)
        Me.LblB.Name = "LblB"
        Me.LblB.Size = New System.Drawing.Size(22, 20)
        Me.LblB.TabIndex = 25
        Me.LblB.Text = "B"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(5, 175)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(21, 20)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "A"
        '
        'BtnNext
        '
        Me.BtnNext.BackColor = System.Drawing.Color.Gold
        Me.BtnNext.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnNext.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnNext.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnNext.Location = New System.Drawing.Point(349, 418)
        Me.BtnNext.Margin = New System.Windows.Forms.Padding(4)
        Me.BtnNext.Name = "BtnNext"
        Me.BtnNext.Size = New System.Drawing.Size(169, 28)
        Me.BtnNext.TabIndex = 23
        Me.BtnNext.TabStop = False
        Me.BtnNext.Text = "Next Question"
        Me.BtnNext.UseVisualStyleBackColor = False
        '
        'TxtQuestion
        '
        Me.TxtQuestion.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TxtQuestion.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtQuestion.Location = New System.Drawing.Point(29, 22)
        Me.TxtQuestion.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TxtQuestion.Multiline = True
        Me.TxtQuestion.Name = "TxtQuestion"
        Me.TxtQuestion.ReadOnly = True
        Me.TxtQuestion.Size = New System.Drawing.Size(489, 115)
        Me.TxtQuestion.TabIndex = 22
        Me.TxtQuestion.TabStop = False
        '
        'BtnFinal
        '
        Me.BtnFinal.BackColor = System.Drawing.Color.Gold
        Me.BtnFinal.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnFinal.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnFinal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnFinal.Location = New System.Drawing.Point(29, 418)
        Me.BtnFinal.Margin = New System.Windows.Forms.Padding(4)
        Me.BtnFinal.Name = "BtnFinal"
        Me.BtnFinal.Size = New System.Drawing.Size(169, 28)
        Me.BtnFinal.TabIndex = 21
        Me.BtnFinal.TabStop = False
        Me.BtnFinal.Text = "Final Answer"
        Me.BtnFinal.UseVisualStyleBackColor = False
        '
        'RadD
        '
        Me.RadD.AutoSize = True
        Me.RadD.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadD.Location = New System.Drawing.Point(34, 363)
        Me.RadD.Margin = New System.Windows.Forms.Padding(4)
        Me.RadD.Name = "RadD"
        Me.RadD.Size = New System.Drawing.Size(17, 16)
        Me.RadD.TabIndex = 20
        Me.RadD.UseVisualStyleBackColor = True
        '
        'RadB
        '
        Me.RadB.AutoSize = True
        Me.RadB.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadB.Location = New System.Drawing.Point(34, 241)
        Me.RadB.Margin = New System.Windows.Forms.Padding(4)
        Me.RadB.Name = "RadB"
        Me.RadB.Size = New System.Drawing.Size(17, 16)
        Me.RadB.TabIndex = 19
        Me.RadB.UseVisualStyleBackColor = True
        '
        'RadC
        '
        Me.RadC.AutoSize = True
        Me.RadC.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadC.Location = New System.Drawing.Point(33, 302)
        Me.RadC.Margin = New System.Windows.Forms.Padding(4)
        Me.RadC.Name = "RadC"
        Me.RadC.Size = New System.Drawing.Size(17, 16)
        Me.RadC.TabIndex = 18
        Me.RadC.UseVisualStyleBackColor = True
        '
        'BtnPhone
        '
        Me.BtnPhone.BackColor = System.Drawing.Color.Transparent
        Me.BtnPhone.BackgroundImage = CType(resources.GetObject("BtnPhone.BackgroundImage"), System.Drawing.Image)
        Me.BtnPhone.Location = New System.Drawing.Point(53, 41)
        Me.BtnPhone.Margin = New System.Windows.Forms.Padding(4)
        Me.BtnPhone.Name = "BtnPhone"
        Me.BtnPhone.Size = New System.Drawing.Size(79, 78)
        Me.BtnPhone.TabIndex = 0
        Me.BtnPhone.TabStop = False
        Me.BtnPhone.UseVisualStyleBackColor = False
        '
        'Btn50_50
        '
        Me.Btn50_50.BackgroundImage = CType(resources.GetObject("Btn50_50.BackgroundImage"), System.Drawing.Image)
        Me.Btn50_50.Location = New System.Drawing.Point(224, 41)
        Me.Btn50_50.Margin = New System.Windows.Forms.Padding(4)
        Me.Btn50_50.Name = "Btn50_50"
        Me.Btn50_50.Size = New System.Drawing.Size(79, 78)
        Me.Btn50_50.TabIndex = 1
        Me.Btn50_50.TabStop = False
        Me.Btn50_50.UseVisualStyleBackColor = True
        '
        'BtnAudience
        '
        Me.BtnAudience.BackgroundImage = CType(resources.GetObject("BtnAudience.BackgroundImage"), System.Drawing.Image)
        Me.BtnAudience.Location = New System.Drawing.Point(387, 41)
        Me.BtnAudience.Margin = New System.Windows.Forms.Padding(4)
        Me.BtnAudience.Name = "BtnAudience"
        Me.BtnAudience.Size = New System.Drawing.Size(87, 78)
        Me.BtnAudience.TabIndex = 2
        Me.BtnAudience.TabStop = False
        Me.BtnAudience.UseVisualStyleBackColor = True
        '
        'GrpHelpers
        '
        Me.GrpHelpers.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.GrpHelpers.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GrpHelpers.BackColor = System.Drawing.Color.Olive
        Me.GrpHelpers.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GrpHelpers.CausesValidation = False
        Me.GrpHelpers.Controls.Add(Me.BtnAudience)
        Me.GrpHelpers.Controls.Add(Me.Btn50_50)
        Me.GrpHelpers.Controls.Add(Me.BtnPhone)
        Me.GrpHelpers.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GrpHelpers.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GrpHelpers.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrpHelpers.ForeColor = System.Drawing.Color.Gold
        Me.GrpHelpers.Location = New System.Drawing.Point(391, 21)
        Me.GrpHelpers.Margin = New System.Windows.Forms.Padding(4)
        Me.GrpHelpers.Name = "GrpHelpers"
        Me.GrpHelpers.Padding = New System.Windows.Forms.Padding(0)
        Me.GrpHelpers.Size = New System.Drawing.Size(533, 143)
        Me.GrpHelpers.TabIndex = 16
        Me.GrpHelpers.TabStop = False
        Me.GrpHelpers.Text = "Life Lines"
        '
        'TxtCash
        '
        Me.TxtCash.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TxtCash.BackColor = System.Drawing.Color.Black
        Me.TxtCash.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtCash.ForeColor = System.Drawing.Color.Gold
        Me.TxtCash.Location = New System.Drawing.Point(12, 444)
        Me.TxtCash.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TxtCash.Multiline = True
        Me.TxtCash.Name = "TxtCash"
        Me.TxtCash.ReadOnly = True
        Me.TxtCash.Size = New System.Drawing.Size(121, 98)
        Me.TxtCash.TabIndex = 19
        Me.TxtCash.TabStop = False
        Me.TxtCash.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AccessibleDescription = " "
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Black
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Gold
        Me.Label1.Location = New System.Drawing.Point(13, 411)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(121, 25)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "Cash Won:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'BtnExit
        '
        Me.BtnExit.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.BtnExit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnExit.ForeColor = System.Drawing.Color.Gold
        Me.BtnExit.Location = New System.Drawing.Point(13, 548)
        Me.BtnExit.Margin = New System.Windows.Forms.Padding(4)
        Me.BtnExit.Name = "BtnExit"
        Me.BtnExit.Size = New System.Drawing.Size(139, 78)
        Me.BtnExit.TabIndex = 21
        Me.BtnExit.TabStop = False
        Me.BtnExit.Text = "Quit Game"
        Me.BtnExit.UseVisualStyleBackColor = False
        '
        'BtnRules
        '
        Me.BtnRules.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.BtnRules.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnRules.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnRules.ForeColor = System.Drawing.Color.Gold
        Me.BtnRules.Location = New System.Drawing.Point(13, 288)
        Me.BtnRules.Margin = New System.Windows.Forms.Padding(4)
        Me.BtnRules.Name = "BtnRules"
        Me.BtnRules.Size = New System.Drawing.Size(105, 43)
        Me.BtnRules.TabIndex = 22
        Me.BtnRules.TabStop = False
        Me.BtnRules.Text = "Rules"
        Me.BtnRules.UseVisualStyleBackColor = False
        '
        'BtnCreate
        '
        Me.BtnCreate.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.BtnCreate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnCreate.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCreate.ForeColor = System.Drawing.Color.Gold
        Me.BtnCreate.Location = New System.Drawing.Point(12, 7)
        Me.BtnCreate.Margin = New System.Windows.Forms.Padding(4)
        Me.BtnCreate.Name = "BtnCreate"
        Me.BtnCreate.Size = New System.Drawing.Size(168, 78)
        Me.BtnCreate.TabIndex = 23
        Me.BtnCreate.TabStop = False
        Me.BtnCreate.Text = "Create Questions"
        Me.BtnCreate.UseVisualStyleBackColor = False
        '
        'BtnLoad
        '
        Me.BtnLoad.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.BtnLoad.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnLoad.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLoad.ForeColor = System.Drawing.Color.Gold
        Me.BtnLoad.Location = New System.Drawing.Point(12, 93)
        Me.BtnLoad.Margin = New System.Windows.Forms.Padding(4)
        Me.BtnLoad.Name = "BtnLoad"
        Me.BtnLoad.Size = New System.Drawing.Size(168, 78)
        Me.BtnLoad.TabIndex = 24
        Me.BtnLoad.TabStop = False
        Me.BtnLoad.Text = "Load Questions"
        Me.BtnLoad.UseVisualStyleBackColor = False
        '
        'BtnNew
        '
        Me.BtnNew.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.BtnNew.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnNew.ForeColor = System.Drawing.Color.Gold
        Me.BtnNew.Location = New System.Drawing.Point(12, 632)
        Me.BtnNew.Margin = New System.Windows.Forms.Padding(4)
        Me.BtnNew.Name = "BtnNew"
        Me.BtnNew.Size = New System.Drawing.Size(139, 78)
        Me.BtnNew.TabIndex = 25
        Me.BtnNew.TabStop = False
        Me.BtnNew.Text = "New Game"
        Me.BtnNew.UseVisualStyleBackColor = False
        '
        'FrmWhoMillionare
        '
        Me.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(1006, 723)
        Me.Controls.Add(Me.BtnNew)
        Me.Controls.Add(Me.BtnLoad)
        Me.Controls.Add(Me.BtnCreate)
        Me.Controls.Add(Me.BtnRules)
        Me.Controls.Add(Me.BtnExit)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TxtCash)
        Me.Controls.Add(Me.LblA)
        Me.Controls.Add(Me.GrpHelpers)
        Me.Controls.Add(Me.BtnPlay)
        Me.Controls.Add(Me.lblMillion)
        Me.Controls.Add(Me.Lbl500k)
        Me.Controls.Add(Me.Lbl250k)
        Me.Controls.Add(Me.Lbl125k)
        Me.Controls.Add(Me.Lbl64k)
        Me.Controls.Add(Me.Lbl32k)
        Me.Controls.Add(Me.Lbl16k)
        Me.Controls.Add(Me.Lbl8k)
        Me.Controls.Add(Me.Lbl4k)
        Me.Controls.Add(Me.Lbl2k)
        Me.Controls.Add(Me.Lbl1k)
        Me.Controls.Add(Me.Lbl500)
        Me.Controls.Add(Me.Lbl300)
        Me.Controls.Add(Me.Lbl200)
        Me.Controls.Add(Me.lbl100)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "FrmWhoMillionare"
        Me.Text = "Millionare"
        Me.TransparencyKey = System.Drawing.Color.Transparent
        Me.LblA.ResumeLayout(False)
        Me.LblA.PerformLayout()
        Me.GrpHelpers.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lbl100 As System.Windows.Forms.Label
    Friend WithEvents Lbl200 As System.Windows.Forms.Label
    Friend WithEvents Lbl300 As System.Windows.Forms.Label
    Friend WithEvents Lbl500 As System.Windows.Forms.Label
    Friend WithEvents Lbl1k As System.Windows.Forms.Label
    Friend WithEvents Lbl2k As System.Windows.Forms.Label
    Friend WithEvents Lbl4k As System.Windows.Forms.Label
    Friend WithEvents Lbl8k As System.Windows.Forms.Label
    Friend WithEvents Lbl16k As System.Windows.Forms.Label
    Friend WithEvents Lbl32k As System.Windows.Forms.Label
    Friend WithEvents Lbl64k As System.Windows.Forms.Label
    Friend WithEvents Lbl125k As System.Windows.Forms.Label
    Friend WithEvents Lbl250k As System.Windows.Forms.Label
    Friend WithEvents Lbl500k As System.Windows.Forms.Label
    Friend WithEvents lblMillion As System.Windows.Forms.Label
    Friend WithEvents BtnPlay As System.Windows.Forms.Button
    Friend WithEvents RadA As System.Windows.Forms.RadioButton
    Friend WithEvents LblA As System.Windows.Forms.Panel
    Friend WithEvents RadD As System.Windows.Forms.RadioButton
    Friend WithEvents RadB As System.Windows.Forms.RadioButton
    Friend WithEvents RadC As System.Windows.Forms.RadioButton
    Friend WithEvents BtnFinal As System.Windows.Forms.Button
    Friend WithEvents BtnPhone As System.Windows.Forms.Button
    Friend WithEvents Btn50_50 As System.Windows.Forms.Button
    Friend WithEvents BtnAudience As System.Windows.Forms.Button
    Friend WithEvents GrpHelpers As System.Windows.Forms.GroupBox
    Friend WithEvents TxtCash As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TxtQuestion As System.Windows.Forms.TextBox
    Friend WithEvents BtnExit As System.Windows.Forms.Button
    Friend WithEvents BtnNext As System.Windows.Forms.Button
    Friend WithEvents BtnRules As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents LblD As System.Windows.Forms.Label
    Friend WithEvents LblC As System.Windows.Forms.Label
    Friend WithEvents LblB As System.Windows.Forms.Label
    Friend WithEvents BtnCreate As System.Windows.Forms.Button
    Friend WithEvents BtnLoad As System.Windows.Forms.Button
    Friend WithEvents BtnNew As System.Windows.Forms.Button

End Class
